#include "os_interface.cpp"

/*
    BALINGIT, JAVIER, RAMOS

 * Task: MCO1
 */


int main() {
    menu();
    exit_os(0);
    return 0;
}
